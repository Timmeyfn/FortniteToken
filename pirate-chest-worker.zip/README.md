# Pirate Chest — Cloudflare Worker

Everything (page, chest + reward images, API) is inside `worker.js`.

## Deploy with the dashboard (no install)
1. Cloudflare dashboard → **Workers & Pages → Create → Create Worker**, name it `pirate-chest`, click **Deploy**.
2. Click **Edit code**, delete the sample, paste the whole of `worker.js`, click **Deploy**.
3. Leaderboard storage: **Storage & Databases → KV → Create namespace** (call it `pirate-chest-lb`).
4. Back on the Worker: **Settings → Bindings → Add → KV namespace**, variable name **`LB`**, pick the namespace, save.
5. Open `https://pirate-chest.<your-subdomain>.workers.dev`.

## Deploy with Wrangler
```
npx wrangler kv namespace create LB      # copy the id into wrangler.toml
npx wrangler deploy
```

## Notes
- Chests are rolled on the server, so the leaderboard can't be edited from the browser.
- Each visitor gets a random anonymous ID saved in their browser, shown as "Anonymous #1234".
- Inventory and the chests-opened count are saved in the visitor's browser. Pirate Tokens are saved on the server.
- KV is written only when someone wins a token, so you stay well inside the free tier.
- Without the `LB` binding, the site still works, but the leaderboard resets whenever the Worker restarts.
- To change odds or rewards, edit the `REWARDS` list near the top of `worker.js`. The same list appears in the page's script inside `HTML`; keep both in sync.
